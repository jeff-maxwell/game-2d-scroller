 font - Sad Kropotkin Laugh
https://www.dafont.com/sad-kropotkin-laugh.font?l[]=10&l[]=1&text=DESERT